/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import mvc.db.DBConnection;

/**
 *
 * @author USER
 */
public class PatientsModel {
    
    private String Number;
    private String Name;
    private String Gender;
    private String Phone;
    private String Address;
    private String DOB;
    
    public PatientsModel(){
        
        
    }
    
    public PatientsModel( String Number, String Name, String Gender,String Phone, String Address,String DOB){
        
        this.Number= Number;
        this.Name=Name;
        this.Gender=Gender;
        this.Phone=Phone;
        this.Address=Address; 
        this.DOB=DOB;
        
    }

    public void setNumber(String Number) {
        this.Number = Number;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public void setPhone(String Phone) {
        this.Phone = Phone;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public String getNumber() {
        return Number;
    }

    public String getName() {
        return Name;
    }

    public String getGender() {
        return Gender;
    }

    public String getPhone() {
        return Phone;
    }

    public String getAddress() {
        return Address;
    }

    public String getDOB() {
        return DOB;
    }
    
    
}
            

    
    
    
    
    

