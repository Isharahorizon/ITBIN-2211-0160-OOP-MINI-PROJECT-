/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.model;

/**
 *
 * @author USER
 */
public class ResultsModel {
    
    private String Number;
    
    
    private String Result;
   
    private String DOB;
    
    
    public ResultsModel()
    {
        
    }
    
    public ResultsModel(String Number,String Id, String code, String Result,String Cost,  String DOB){
        this.Number  = Number;
        
        
        this.Result=Result;
        
        this.DOB =DOB;
    }

    public void setNumber(String Number) {
        this.Number = Number;
    }

    

    

    public void setResult(String Result) {
        this.Result = Result;
    }

   

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public String getNumber() {
        return Number;
    }

    
    

  

    public String getResult() {
        return Result;
    }

    

    public String getDOB() {
        return DOB;
    }
    
    
    
    
}
