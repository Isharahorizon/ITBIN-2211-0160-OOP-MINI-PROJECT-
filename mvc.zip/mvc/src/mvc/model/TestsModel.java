/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.model;

import java.awt.List;
import java.util.ArrayList;


/**
 *
 * @author USER
 */
public class TestsModel {
    
   
    
    private String Number;
    private String Name;
    private String Cost;
    
   
    
    
    public TestsModel(){
//        
//        
  }
    
    public TestsModel(String Number, String Name, String Cost){
        
        this.Name=Name;
        this.Number=Number;
        this.Cost=Cost;
        
        
    }

    public void setNumber(String Number) {
        this.Number = Number;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setCost(String Cost) {
        this.Cost = Cost;
    }

    public String getNumber() {
        return Number;
    }

    public String getName() {
        return Name;
    }

    public String getCost() {
        return Cost;
    }
    
    
   


}
    

