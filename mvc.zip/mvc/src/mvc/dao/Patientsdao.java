/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import mvc.db.DBConnection;
import mvc.model.PatientsModel;

import java.util.List;

/**
 *
 * @author USER
 */
public class Patientsdao {

    
    
    public List<String[]> getData()
          
  {
      
    List<String[]> userData = new ArrayList<>();

    String getData = "SELECT * FROM patienttbl";

    try{
        Connection connection = DBConnection.getConnection();
         PreparedStatement pst = connection.prepareStatement(getData);
         ResultSet rs = pst.executeQuery();

      while (rs.next()) {
        String[] user = new String[6]; // Assuming username and password
        
                user[0] = String.valueOf(rs.getInt("PatNum")); 
                user[1] = rs.getString("PatName");
                user[2] = rs.getString("PatGen");
                user[3] = rs.getString("PatAdd");
                user[4] = rs.getString("PatPhone");
                user[5] = rs.getString("PatDOB");
                
                
                
                userData.add(user);

       
      }
      }
    
    catch (SQLException e) {
      e.printStackTrace();
    }

    return userData;
    
  }
    
    public void delete(int id) throws SQLException{
        System.out.println(id);
        
        String deleteQuery ="DELETE FROM patienttbl WHERE PatNum = '"+id+"'";
        try{
            Connection connection = DBConnection.getConnection();
            PreparedStatement pst = connection.prepareStatement(deleteQuery);
            
            
            pst.executeUpdate();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }
    
    
    
    

    
     public void addPatient(PatientsModel Tests){
        String sql = "INSERT INTO patienttbl(PatNum,PatName,PatGen,PatAdd,PatPhone,PatDOB) VALUES (?,?,?,?,?,?)";
        try{
            Connection connection = DBConnection.getConnection();
            PreparedStatement stmt = connection.prepareStatement(sql);
            
            stmt.setString(1,Tests.getNumber());
            stmt.setString(2,Tests.getName());
            stmt.setString(3,Tests.getGender());
            stmt.setString(4,Tests.getPhone());
            stmt.setString(5,Tests.getAddress());
            stmt.setString(6,Tests.getDOB());
            
            
            stmt.executeUpdate();
        }catch(SQLException e){
            e.printStackTrace();
        }
        
    }
     
     public void update(PatientsModel item){
         
        String sql = "UPDATE petienttbl SET PatName = ?,PatGen = ?,PatAdd = ?,PatPhone = ?,PatDOB =? WHERE PatNum = ?";
        try{
            Connection connection = DBConnection.getConnection();
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1,item.getNumber());
            stmt.setString(2,item.getName());
            stmt.setString(3,item.getGender());
            stmt.setString(4,item.getPhone());
            stmt.setString(5,item.getAddress());
            stmt.setString(6,item.getDOB());
            stmt.executeUpdate();
        }catch(SQLException e){
            e.printStackTrace();
        }

     } 
}
   

