/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import mvc.db.DBConnection;
import mvc.model.ResultsModel;
import mvc.model.TestsModel;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USER
 */
public class Resultsdao {
    public List<String[]> getAllItems(){
          
  
      
    List<String[]> userData = new ArrayList<>();

    String getData = "SELECT * FROM resulttbl";

    try{
        Connection connection = DBConnection.getConnection();
         PreparedStatement pst = connection.prepareStatement(getData);
         ResultSet rs = pst.executeQuery();

      while (rs.next()) {
        String[] user = new String[3]; // Assuming username and password
        
                user[0] = String.valueOf(rs.getInt("ResNum")); 
                user[1] = rs.getString("Results");
                user[2] = rs.getString("Resdate");
                
                
                
                userData.add(user);

       
      }
      } catch (SQLException e) {
      e.printStackTrace();
    }

    return userData;
    
  }
    
    public void delete(int id) throws SQLException{
        System.out.println(id);
        
        String deleteQuery ="DELETE FROM resulttbl WHERE ResNum = '"+id+"'";
        try{
            Connection connection = DBConnection.getConnection();
            PreparedStatement pst = connection.prepareStatement(deleteQuery);
            
            
            pst.executeUpdate();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    
    
    
     

     
     public void add(ResultsModel Results){
        String sql = "INSERT INTO resulttbl(ResNum,Result,ResDate,Cost,PatID,TestDone) VALUES (?,?,?,?,?,?)";
        try{
            Connection connection = DBConnection.getConnection();
            PreparedStatement stmt = connection.prepareStatement(sql);
            
            stmt.setString(1,Results.getNumber());
            stmt.setString(2,Results.getResult());
            stmt.setString(3,Results.getDOB());
            
            
            
            stmt.executeUpdate();
        }catch(SQLException e){
            e.printStackTrace();
        }
        
    }
     
      
    
}

