/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import mvc.db.DBConnection;
import mvc.model.TestsModel;
import java.util.List;


/**
 *
 * @author USER
 */
public class Testsdao {
    
     public List<String[]> getAllItems(){
          
  
      
    List<String[]> userData = new ArrayList<>();

    String getData = "SELECT * FROM testtbl";

    try{
        Connection connection = DBConnection.getConnection();
         PreparedStatement pst = connection.prepareStatement(getData);
         ResultSet rs = pst.executeQuery();

      while (rs.next()) {
        String[] user = new String[4]; // Assuming username and password
        
                user[0] = String.valueOf(rs.getInt("TestCode")); 
                user[1] = rs.getString("TestName");
                user[2] = rs.getString("TestCost");
                
                
                
                userData.add(user);

       
      }
      } catch (SQLException e) {
      e.printStackTrace();
    }

    return userData;
    
  }
    
    public void delete(int id) throws SQLException{
        System.out.println(id);
        
        String deleteQuery ="DELETE FROM testtbl WHERE TestCode = '"+id+"'";
        try{
            Connection connection = DBConnection.getConnection();
            PreparedStatement pst = connection.prepareStatement(deleteQuery);
            
            
            pst.executeUpdate();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }
    
    
    
    public void addPatient(TestsModel Tests){
        String sql = "INSERT INTO testtbl(TestCode,TestName,TestCost) VALUES (?,?,?)";
        try{
            Connection connection = DBConnection.getConnection();
            PreparedStatement stmt = connection.prepareStatement(sql);
            
            stmt.setString(1,Tests.getNumber());
            stmt.setString(2,Tests.getName());
            stmt.setString(3,Tests.getCost());
            
            
            stmt.executeUpdate();
        }catch(SQLException e){
            e.printStackTrace();
        }
        
    }
     
    
 

 public void update(TestsModel item){
        String sql = "UPDATE testtbl SET TestName = ?, Cost = ? WHERE TestCode = ?";
        try{
            Connection connection = DBConnection.getConnection();
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1,item.getName());
            stmt.setString(2,item.getNumber());
            stmt.setString(3,item.getName());
            stmt.setString(4,item.getCost());
            stmt.executeUpdate();
        }catch(SQLException e){
            e.printStackTrace();
}
}

    
    
     
 
}
