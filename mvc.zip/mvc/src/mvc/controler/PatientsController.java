/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.controler;

import java.util.List;
import javax.swing.JOptionPane;
import mvc.dao.Patientsdao;
import mvc.view.PatientsView;

/**
 *
 * @author USER
 */
private final PatientsView view;
    private  Patientsdao dao;

    public Patientscontroller(PatientsView view) {
        this.view = view;
         this.dao = new itemDAO(); 
        initComponents();
    }

public void delete(int id) {
        try {
            dao.delete(id);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(view, "Error deleting user: " + e.getMessage());
        }
    }
public void update1(itemModel item ) {
     
        try {
            dao.update(item);
           
        } catch (Exception e) {
            JOptionPane.showMessageDialog(view, "Error deleting user: " + e.getMessage());
        }
    }
//public class PatientsController {
//    private Patientsdao patientsdao;
//
//    public PatientsController() {
//        this.patientsdao = new Patientsdao();//chtgpt
//    }
//
//    public List<String[]> getAllPatients() {
//        return patientsdao.getAllPatients();
//    }
//}
//public class PatientsController {
//    private final PatientsView view;
//    private  PatientsView dao;
//
//    public PatientsController(PatientsView view) {
//        this.view = view;
//         this.dao = new Patientsdao(); 
//        initComponents();
//    }

//    private void initComponents() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//    private final PatientsView view;
//    private  Patientsdao dao;

//    public PatientsController(PatientsView view) {
//        this.view = view;
//         this.dao = new Patientsdao(); 
//        initComponents();
//}
    public void delete(int id) {
        try {
            dao.delete();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(view, "Error deleting user: " + e.getMessage());
}
}
    public void update1(PatientsModel item ) {
     
        try {
            dao.update(item);
           
        } catch (Exception e) {
            JOptionPane.showMessageDialog(view, "Error deleting user: " + e.getMessage());
}
}
    
}
