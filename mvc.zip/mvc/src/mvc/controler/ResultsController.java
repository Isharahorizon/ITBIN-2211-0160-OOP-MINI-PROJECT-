/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.controler;

import javax.swing.JOptionPane;
import mvc.dao.Resultsdao;

import mvc.dao.Testsdao;
import mvc.view.ResultsView;
import mvc.view.TestsView;

/**
 *
 * @author USER
 */
public class ResultsController {
    
    private final ResultsView view;
    private  Resultsdao dao;

  

    public ResultsController(ResultsView view) {
        this.view = view;
        this.dao = new Resultsdao(); 
        initComponents();
    }

    
     public void delete(int id) {
        try {
            dao.delete(id);
            //view.refreshTableData(); // Optional: Update table data after successful deletion (implementation depends on your table model)
        } catch (Exception e) {
            JOptionPane.showMessageDialog(view, "Error deleting user: " + e.getMessage());
        }
    }

    private void initComponents() {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
