/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.controler;

import javax.swing.JOptionPane;
import mvc.dao.Testsdao;
import mvc.model.TestsModel;
import mvc.view.TestsView;

/**
 *
 * @author USER
 */
public class Testscontroler {
    private final TestsView view;
    private  Testsdao dao;

  

    public Testscontroler(TestsView view) {
        this.view = view;
         this.dao = new Testsdao(); 
        initComponents();
    }

    
     public void delete(int id) {
        try {
            dao.delete(id);
            //view.refreshTableData(); // Optional: Update table data after successful deletion (implementation depends on your table model)
        } catch (Exception e) {
            JOptionPane.showMessageDialog(view, "Error deleting user: " + e.getMessage());
        }
    }

    private void initComponents() {
      
    }

    public void update(TestsModel item) {
        ///throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void update1(TestsModel item) {
        ////throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void update1(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
  
    

   
}
